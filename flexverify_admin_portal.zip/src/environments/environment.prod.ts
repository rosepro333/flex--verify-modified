export const environment = {
  production: true,
  // apiUrl: 'https://verify.flexm.com/api',
  apiUrl: 'http://34.96.241.161/api',
  showDataSource: true,
};
