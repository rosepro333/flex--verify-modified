export interface TenentUser {
    type: string;
    tenent: string;
    name:string;
    email:string;
}